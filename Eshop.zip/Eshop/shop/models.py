from django.db import models
from PIL import Image

class Category(models.Model):
    name=models.CharField(max_length=50)
    category_id = models.AutoField
    def __str__(self):
        return self.name

class Sub_Category(models.Model):
    sub_category_id = models.AutoField
    name=models.CharField(max_length=50)
    category=models.ForeignKey(Category,on_delete=models.PROTECT,default=True)

    def __str__(self):
        #"""String for representing the Model object."""
        #return f'{self.sub_category_id}, {self.name}'
         return str (self.name)

class Seller(models.Model):
    shope_name = models.CharField(max_length=100)
    seller_name=models.CharField(max_length=100)
    shop_address = models.CharField(max_length=100)
    seller_mobile=models.IntegerField()
    pin = models.IntegerField()
    status=models.IntegerField()

    def __str__(self):
        return self.shope_name

class Product(models.Model):
    product_id=models.AutoField
    product_name=models.CharField(max_length=50)
    sub_category= models.ForeignKey(Sub_Category,on_delete=models.PROTECT)
    price=models.IntegerField(default=0)
    desc=models.CharField(max_length=300,null=True)
    pub_date=models.DateField(auto_now_add=True,null=True)
    image= models.ImageField(upload_to="shop/images",default="",null=True)
    seller = models.ForeignKey(Seller, on_delete=models.PROTECT, default=True)
    seller_name = models.CharField(max_length=50,default=True)

    def save(self, *args,**kwargs):
        super().save(*args,**kwargs)
        img = Image.open(self.image.path)
        if img.height  or img.weidht :
            output_size = (200,200)
            img.thumbnail(output_size)
            img.save(self.image.path)


    def __str__(self):
        return self.product_name

class Customer(models.Model):
    mobile=models.IntegerField(unique=True)
    name=models.CharField(max_length=200,null=True)
    addrress = models.CharField(max_length=200, null=True)


class Cart(models.Model):
    mobile = models.IntegerField()
    product = models.ForeignKey(Product, on_delete=models.CASCADE,default=True)
    product_name = models.CharField(max_length=50,default=True)
    qty = models.IntegerField(default=1)
    price = models.IntegerField()
    totalprice = models.IntegerField(default=1)

    def __str__(self):
        return str(self.id)
    @property
    def total_cost(self):
        return self.qty * self.product.price

STATUS_CHOICES = (
  ('Accepted','Accepted'),
  ('Packed','Packed'),
  ('On The Way','On The Way'),
  ('Delivered','Delivered'),
  ('Cancel','Cancel')
)

INSTOCK_OUTSTOCK_CHOICE=(
    ('1','in stock'),
    ('0','out of stock')
)


class OrderMaster(models.Model):
    customer = models.IntegerField()
    mobile = models.IntegerField(default=True)
    name = models.CharField(max_length=200, null=True)
    addrress = models.CharField(max_length=200, null=True)
    total_price = models.IntegerField()
    status = models.CharField(max_length=50,default='pending')
    ordered_date = models.DateTimeField(auto_now_add=True,null=True)


class OrderDetail(models.Model):
    mobile = models.IntegerField(default=True)
    product=models.IntegerField(default=True)
    product_name = models.CharField(max_length=50, default=True)
    seller_name = models.CharField(max_length=50, default=True)
    qty = models.PositiveIntegerField(default=1)
    price = models.IntegerField()
    totalprice = models.IntegerField(default=True)
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50,choices=INSTOCK_OUTSTOCK_CHOICE,default=1)
    orderfilter = models.IntegerField(default=True)

    @property
    def total_cost(self):
        return self.qty * self.product.price

class Seller_Shope_Category(models.Model):
    seller_id=models.IntegerField()
    category_id=models.IntegerField()

class Order_Status(models.Model):
    name=models.CharField(max_length=50)

class Staf(models.Model):
    name=models.CharField(max_length=50)
    mobile = models.IntegerField()
    pin = models.IntegerField()
